import json

# Read the collected errors
with open('all_errors_raw.json', 'r', encoding='utf-8') as f:
    all_errors = json.load(f)

def get_cause_analysis(raw_error, category):
    if 'upstream' in raw_error.lower() or '503' in raw_error:
        return '模型服务连接失败，可能是网络延迟、服务宕机或防火墙阻止连接'
    elif 'max_tokens' in raw_error or 'context length' in raw_error:
        return '对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史'
    elif 'getaddrinfo' in raw_error or 'ENOTFOUND' in raw_error:
        return 'DNS 解析失败，容器内 DNS 配置问题或目标网站被防火墙阻止'
    elif 'ENOENT' in raw_error or 'not found' in raw_error.lower():
        return '请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误'
    elif 'preflight' in raw_error:
        return '安全沙箱机制阻止潜在危险的命令执行'
    elif 'required' in raw_error.lower():
        return 'Tool 调用时缺少必需参数'
    elif 'aborted' in raw_error.lower():
        return '请求被主动中止，可能是超时或用户取消'
    elif 'node required' in raw_error:
        return 'Canvas 工具调用时缺少必需的节点参数'
    elif 'JSON5' in raw_error or 'SyntaxError' in raw_error:
        return '配置文件 JSON 格式错误'
    elif 'cron' in raw_error.lower():
        return '定时任务配置不正确，需要检查 sessionTarget 和 payload.kind 设置'
    elif 'Invalid model name' in raw_error:
        return '配置的模型名称在 API 中不存在或不可用'
    else:
        return '需进一步分析具体原因'

# Generate Markdown report
md_content = '''# OpenClaw Session Error Report

## 问题清单

本文档记录了 OpenClaw 实例在对话过程中出现的所有错误，按错误类型分类整理。

---

## 错误统计

- **总错误数**: ''' + str(len(all_errors)) + ''' 条
- **API/Model 错误**: ''' + str(len([e for e in all_errors if 'API/Model' in e['error_type']])) + ''' 条
- **Tool 执行错误**: ''' + str(len([e for e in all_errors if 'Tool Error' in e['error_type']])) + ''' 条

---

## 详细错误清单

'''

# Group errors by type for organized output
error_groups = {}
for err in all_errors:
    key = err['error_type']
    if key not in error_groups:
        error_groups[key] = []
    error_groups[key].append(err)

# Output each error as a separate record
record_num = 1
for error_type, errors in error_groups.items():
    md_content += f'\n### {error_type}\n\n'

    for err in errors:
        # Determine error category based on raw_error content
        raw = err['raw_error']
        if 'upstream' in raw.lower() or '503' in raw or 'reset' in raw.lower():
            category = '上游连接错误'
        elif 'max_tokens' in raw or 'context length' in raw:
            category = 'Token 超限错误'
        elif 'getaddrinfo' in raw or 'ENOTFOUND' in raw:
            category = 'DNS 解析失败'
        elif 'ENOENT' in raw or 'not found' in raw.lower():
            category = '文件/资源未找到'
        elif 'preflight' in raw:
            category = '安全沙箱拦截'
        elif 'required' in raw.lower() or 'missing' in raw.lower():
            category = '缺少必需参数'
        elif 'aborted' in raw.lower():
            category = '请求被中止'
        elif 'node required' in raw:
            category = 'Canvas 节点缺失'
        elif 'complex interpreter' in raw:
            category = '复杂命令被拦截'
        elif 'JSON5' in raw or 'SyntaxError' in raw:
            category = 'JSON 解析错误'
        elif 'cron' in raw.lower():
            category = '定时任务配置错误'
        elif 'Invalid model name' in raw:
            category = '模型名称无效'
        else:
            category = '其他错误'

        cause = get_cause_analysis(err['raw_error'], category)

        md_content += f'''#### 记录 #{record_num}

| 字段 | 内容 |
|------|------|
| **错误类型** | {err['error_type']} |
| **子类型** | {err['error_subtype']} |
| **错误分类** | {category} |
| **时间戳** | {err['timestamp']} |
| **文件位置** | `{err['file']}` |
| **行号** | {err['line']} |

**错误信息**:
```
{err['description']}
```

**原始错误**:
```
{err['raw_error']}
```

**原因分析**: {cause}

---

'''
        record_num += 1

# Write to file
with open('error_report.md', 'w', encoding='utf-8') as f:
    f.write(md_content)

print(f'Generated error_report.md with {record_num-1} records')
