# OpenClaw Session Error Report

## 问题清单

本文档记录了 OpenClaw 实例在对话过程中出现的所有错误，按错误类型分类整理。

---

## 错误统计

- **总错误数**: 162 条
- **API/Model 错误**: 78 条
- **Tool 执行错误**: 84 条

---

## 详细错误清单


### Tool Error (exec)

#### 记录 #1

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-13T07:50:11.685Z |
| **文件位置** | `068ac7a06a47c7fdc26656446b63d7e17dc09d94203abb2c92d6bcf41c33f56705d20342347e3b18cfae39e7a2940bae5fb6ca5293e374cbceee772548768613\agents\main\sessions\3cae69e0-cc25-4849-adba-384ac32a74ca.jsonl` |
| **行号** | 11 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #2

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-14T13:31:23.986Z |
| **文件位置** | `068ac7a06a47c7fdc26656446b63d7e17dc09d94203abb2c92d6bcf41c33f56705d20342347e3b18cfae39e7a2940bae5fb6ca5293e374cbceee772548768613\agents\main\sessions\cda9aafe-3d0a-4cfb-bf9a-40e61755de71.jsonl` |
| **行号** | 19 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #3

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-14T13:31:25.057Z |
| **文件位置** | `068ac7a06a47c7fdc26656446b63d7e17dc09d94203abb2c92d6bcf41c33f56705d20342347e3b18cfae39e7a2940bae5fb6ca5293e374cbceee772548768613\agents\main\sessions\cda9aafe-3d0a-4cfb-bf9a-40e61755de71.jsonl` |
| **行号** | 21 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #4

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-14T13:31:28.035Z |
| **文件位置** | `068ac7a06a47c7fdc26656446b63d7e17dc09d94203abb2c92d6bcf41c33f56705d20342347e3b18cfae39e7a2940bae5fb6ca5293e374cbceee772548768613\agents\main\sessions\cda9aafe-3d0a-4cfb-bf9a-40e61755de71.jsonl` |
| **行号** | 25 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #5

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-13T11:05:27.708Z |
| **文件位置** | `13c13153a543ecba2ba0adb5b621795367f9130736913b4d3bbb5b8244184d6163cd24120cba49ff7f7a07a9b5bb27cc263a5db4d6fc3a9b80b2cf24df09952d\agents\main\sessions\b57d8f72-a5ec-4f01-b83b-4c1f823cc564.jsonl` |
| **行号** | 91 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #6

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-03-30T10:56:22.354Z |
| **文件位置** | `37d31ad6132bab00315c7b7adabe5b839b918500995ce145a03763c66ecc2f612ca90d021c7098f060f5f0547433161ce6af7f6899f2fc1e6f39bab40e12e65a\agents\main\sessions\0af83cd4-10a3-4966-8f3c-2b581a53bf99.jsonl` |
| **行号** | 28 |

**错误信息**:
```
sh: 1: pip3: not found

Command not found
```

**原始错误**:
```
sh: 1: pip3: not found

Command not found
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #7

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-13T08:16:06.430Z |
| **文件位置** | `6fca9aa611cf469e15161f2b342062f7c621c962e44d14a57ee1d61d972f9135cd6f8797feb2302283695088f655118edd65a6768f2159207fd01f575a80e207\agents\main\sessions\f515bf85-1c62-4c9f-ac53-965d068ce9f1.jsonl` |
| **行号** | 13 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #8

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-15T06:24:25.405Z |
| **文件位置** | `a995c7a073fd97cd533a17b62717f0d48e1c6a2d3597fb0668c16564788bde06a2ca13b88f6f674596a9d3f0ae0194307a36103251a8b8cc2ac7cbcc8717ee82\agents\main\sessions\8e991737-22bf-448e-8bbe-c62186c39811.jsonl` |
| **行号** | 19 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #9

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-15T06:24:37.265Z |
| **文件位置** | `a995c7a073fd97cd533a17b62717f0d48e1c6a2d3597fb0668c16564788bde06a2ca13b88f6f674596a9d3f0ae0194307a36103251a8b8cc2ac7cbcc8717ee82\agents\main\sessions\8e991737-22bf-448e-8bbe-c62186c39811.jsonl` |
| **行号** | 27 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #10

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-15T07:10:03.731Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\55f2f268-0c90-49b6-b2e3-91dc2866807d.jsonl` |
| **行号** | 15 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #11

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-15T07:22:24.324Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\569ca63b-4f5f-401e-9fcd-da502d651d2e.jsonl` |
| **行号** | 15 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #12

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-15T07:22:35.479Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\569ca63b-4f5f-401e-9fcd-da502d651d2e.jsonl` |
| **行号** | 31 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #13

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-15T07:26:33.302Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\72301fcf-9f67-400c-94db-6016c8a9d3ce.jsonl` |
| **行号** | 31 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #14

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 缺少必需参数 |
| **时间戳** | 2026-04-15T01:46:58.174Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 81 |

**错误信息**:
```
Exec approval registration failed: Error: gateway closed (1008): pairing required
Gateway target: ws://127.0.0.1:18789
Source: local loopback
Config: /home/node/.openclaw/openclaw.json
Bind: lan
```

**原始错误**:
```
Exec approval registration failed: Error: gateway closed (1008): pairing required
Gateway target: ws://127.0.0.1:18789
Source: local loopback
Config: /home/node/.openclaw/openclaw.json
Bind: lan
```

**原因分析**: Tool 调用时缺少必需参数

---

#### 记录 #15

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-14T06:16:46.256Z |
| **文件位置** | `fa65c292bbe559bed0e01c9bf4ab7206fea633ad01ff275cb3653e15b8eeb8392f5c407ef79ffee6a7cc913e6e645c52665f51d413888ea1d0a0d252182dc6a8\agents\main\sessions\8090b902-7133-4de2-aa1a-feaec3cc3f32.jsonl` |
| **行号** | 29 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #16

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-14T06:17:34.794Z |
| **文件位置** | `fa65c292bbe559bed0e01c9bf4ab7206fea633ad01ff275cb3653e15b8eeb8392f5c407ef79ffee6a7cc913e6e645c52665f51d413888ea1d0a0d252182dc6a8\agents\main\sessions\8090b902-7133-4de2-aa1a-feaec3cc3f32.jsonl` |
| **行号** | 41 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #17

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-13T02:13:32.183Z |
| **文件位置** | `fa65c292bbe559bed0e01c9bf4ab7206fea633ad01ff275cb3653e15b8eeb8392f5c407ef79ffee6a7cc913e6e645c52665f51d413888ea1d0a0d252182dc6a8\agents\main\sessions\dc9038cf-e21f-41ea-98e4-18512d86f492.jsonl` |
| **行号** | 69 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---

#### 记录 #18

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (exec) |
| **子类型** | error |
| **错误分类** | 安全沙箱拦截 |
| **时间戳** | 2026-04-15T03:35:02.710Z |
| **文件位置** | `fd562a2ac4d9c27ae6fb89f180b4bcc6a952f541a4df6dfcf39cf2d994855d7308cd803ff4fbf06f5de44dcdf5532a193bede81430d2492ffbe872bd2244ec92\agents\main\sessions\815b88a2-58be-4689-afc0-60ffb3b13de8.jsonl` |
| **行号** | 23 |

**错误信息**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原始错误**:
```
exec preflight: complex interpreter invocation detected; refusing to run without script preflight validation. Use a direct `python <file>.py` or `node <file>.js` command.
```

**原因分析**: 安全沙箱机制阻止潜在危险的命令执行

---


### Tool Error (web_search)

#### 记录 #19

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_search) |
| **子类型** | error |
| **错误分类** | DNS 解析失败 |
| **时间戳** | 2026-04-16T02:48:00.392Z |
| **文件位置** | `068ac7a06a47c7fdc26656446b63d7e17dc09d94203abb2c92d6bcf41c33f56705d20342347e3b18cfae39e7a2940bae5fb6ca5293e374cbceee772548768613\agents\main\sessions\837503ae-5e31-4723-ac29-12e02f7b233a.jsonl` |
| **行号** | 11 |

**错误信息**:
```
getaddrinfo ENOTFOUND html.duckduckgo.com
```

**原始错误**:
```
getaddrinfo ENOTFOUND html.duckduckgo.com
```

**原因分析**: DNS 解析失败，容器内 DNS 配置问题或目标网站被防火墙阻止

---

#### 记录 #20

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_search) |
| **子类型** | error |
| **错误分类** | DNS 解析失败 |
| **时间戳** | 2026-04-15T05:15:57.951Z |
| **文件位置** | `2839c2f17383d426e0f87c82614743eed21a2aa5a58d39da3b11de6dc56388a31ba9219c47d42da0009bc58633ad7c2f6003d505d1ffb40a96eac87034abf2bf\agents\main\sessions\3b115f85-d481-4522-9123-4f05c4dbf28b.jsonl` |
| **行号** | 15 |

**错误信息**:
```
getaddrinfo ENOTFOUND html.duckduckgo.com
```

**原始错误**:
```
getaddrinfo ENOTFOUND html.duckduckgo.com
```

**原因分析**: DNS 解析失败，容器内 DNS 配置问题或目标网站被防火墙阻止

---

#### 记录 #21

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_search) |
| **子类型** | error |
| **错误分类** | DNS 解析失败 |
| **时间戳** | 2026-04-16T02:46:34.781Z |
| **文件位置** | `2839c2f17383d426e0f87c82614743eed21a2aa5a58d39da3b11de6dc56388a31ba9219c47d42da0009bc58633ad7c2f6003d505d1ffb40a96eac87034abf2bf\agents\main\sessions\7b818780-6f76-441e-a0f4-1cb9520d7c95.jsonl` |
| **行号** | 39 |

**错误信息**:
```
getaddrinfo ENOTFOUND html.duckduckgo.com
```

**原始错误**:
```
getaddrinfo ENOTFOUND html.duckduckgo.com
```

**原因分析**: DNS 解析失败，容器内 DNS 配置问题或目标网站被防火墙阻止

---

#### 记录 #22

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_search) |
| **子类型** | error |
| **错误分类** | DNS 解析失败 |
| **时间戳** | 2026-04-13T06:03:30.674Z |
| **文件位置** | `be76b6e04fcab36478d410ceddf0e791f7e0bc83d9cc084ac90aabdfff9c5a505b0f254d8f12bd554940057385ac72eede19515d37f09e600ab2b03be5443480\agents\main\sessions\b21a5a09-c562-43f4-aeb1-bf5f82cb7a16.jsonl` |
| **行号** | 11 |

**错误信息**:
```
getaddrinfo ENOTFOUND html.duckduckgo.com
```

**原始错误**:
```
getaddrinfo ENOTFOUND html.duckduckgo.com
```

**原因分析**: DNS 解析失败，容器内 DNS 配置问题或目标网站被防火墙阻止

---

#### 记录 #23

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_search) |
| **子类型** | error |
| **错误分类** | DNS 解析失败 |
| **时间戳** | 2026-04-15T01:45:29.548Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 45 |

**错误信息**:
```
getaddrinfo ENOTFOUND html.duckduckgo.com
```

**原始错误**:
```
getaddrinfo ENOTFOUND html.duckduckgo.com
```

**原因分析**: DNS 解析失败，容器内 DNS 配置问题或目标网站被防火墙阻止

---


### Tool Error (web_fetch)

#### 记录 #24

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_fetch) |
| **子类型** | error |
| **错误分类** | DNS 解析失败 |
| **时间戳** | 2026-04-16T02:48:59.742Z |
| **文件位置** | `068ac7a06a47c7fdc26656446b63d7e17dc09d94203abb2c92d6bcf41c33f56705d20342347e3b18cfae39e7a2940bae5fb6ca5293e374cbceee772548768613\agents\main\sessions\837503ae-5e31-4723-ac29-12e02f7b233a.jsonl` |
| **行号** | 17 |

**错误信息**:
```
getaddrinfo ENOTFOUND finance.sina.com.cn
```

**原始错误**:
```
getaddrinfo ENOTFOUND finance.sina.com.cn
```

**原因分析**: DNS 解析失败，容器内 DNS 配置问题或目标网站被防火墙阻止

---

#### 记录 #25

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_fetch) |
| **子类型** | error |
| **错误分类** | DNS 解析失败 |
| **时间戳** | 2026-04-16T02:48:59.751Z |
| **文件位置** | `068ac7a06a47c7fdc26656446b63d7e17dc09d94203abb2c92d6bcf41c33f56705d20342347e3b18cfae39e7a2940bae5fb6ca5293e374cbceee772548768613\agents\main\sessions\837503ae-5e31-4723-ac29-12e02f7b233a.jsonl` |
| **行号** | 18 |

**错误信息**:
```
getaddrinfo ENOTFOUND www.eastmoney.com
```

**原始错误**:
```
getaddrinfo ENOTFOUND www.eastmoney.com
```

**原因分析**: DNS 解析失败，容器内 DNS 配置问题或目标网站被防火墙阻止

---

#### 记录 #26

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_fetch) |
| **子类型** | error |
| **错误分类** | DNS 解析失败 |
| **时间戳** | 2026-04-16T02:48:59.762Z |
| **文件位置** | `068ac7a06a47c7fdc26656446b63d7e17dc09d94203abb2c92d6bcf41c33f56705d20342347e3b18cfae39e7a2940bae5fb6ca5293e374cbceee772548768613\agents\main\sessions\837503ae-5e31-4723-ac29-12e02f7b233a.jsonl` |
| **行号** | 19 |

**错误信息**:
```
getaddrinfo ENOTFOUND www.cailianpress.com
```

**原始错误**:
```
getaddrinfo ENOTFOUND www.cailianpress.com
```

**原因分析**: DNS 解析失败，容器内 DNS 配置问题或目标网站被防火墙阻止

---

#### 记录 #27

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_fetch) |
| **子类型** | error |
| **错误分类** | DNS 解析失败 |
| **时间戳** | 2026-04-15T05:15:59.322Z |
| **文件位置** | `2839c2f17383d426e0f87c82614743eed21a2aa5a58d39da3b11de6dc56388a31ba9219c47d42da0009bc58633ad7c2f6003d505d1ffb40a96eac87034abf2bf\agents\main\sessions\3b115f85-d481-4522-9123-4f05c4dbf28b.jsonl` |
| **行号** | 17 |

**错误信息**:
```
getaddrinfo ENOTFOUND news.sina.com.cn
```

**原始错误**:
```
getaddrinfo ENOTFOUND news.sina.com.cn
```

**原因分析**: DNS 解析失败，容器内 DNS 配置问题或目标网站被防火墙阻止

---

#### 记录 #28

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_fetch) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-14T06:13:45.082Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 27 |

**错误信息**:
```
Blocked: resolves to private/internal/special-use IP address
```

**原始错误**:
```
Blocked: resolves to private/internal/special-use IP address
```

**原因分析**: 需进一步分析具体原因

---

#### 记录 #29

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_fetch) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-13T06:39:16.039Z |
| **文件位置** | `fa65c292bbe559bed0e01c9bf4ab7206fea633ad01ff275cb3653e15b8eeb8392f5c407ef79ffee6a7cc913e6e645c52665f51d413888ea1d0a0d252182dc6a8\agents\main\sessions\1911e9d8-ba88-486d-921c-4631f87747df.jsonl` |
| **行号** | 39 |

**错误信息**:
```
Blocked: resolves to private/internal/special-use IP address
```

**原始错误**:
```
Blocked: resolves to private/internal/special-use IP address
```

**原因分析**: 需进一步分析具体原因

---

#### 记录 #30

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_fetch) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-13T06:42:53.020Z |
| **文件位置** | `fa65c292bbe559bed0e01c9bf4ab7206fea633ad01ff275cb3653e15b8eeb8392f5c407ef79ffee6a7cc913e6e645c52665f51d413888ea1d0a0d252182dc6a8\agents\main\sessions\1911e9d8-ba88-486d-921c-4631f87747df.jsonl` |
| **行号** | 167 |

**错误信息**:
```
Blocked: resolves to private/internal/special-use IP address
```

**原始错误**:
```
Blocked: resolves to private/internal/special-use IP address
```

**原因分析**: 需进一步分析具体原因

---

#### 记录 #31

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (web_fetch) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-13T02:12:42.017Z |
| **文件位置** | `fa65c292bbe559bed0e01c9bf4ab7206fea633ad01ff275cb3653e15b8eeb8392f5c407ef79ffee6a7cc913e6e645c52665f51d413888ea1d0a0d252182dc6a8\agents\main\sessions\dc9038cf-e21f-41ea-98e4-18512d86f492.jsonl` |
| **行号** | 27 |

**错误信息**:
```
Blocked: resolves to private/internal/special-use IP address
```

**原始错误**:
```
Blocked: resolves to private/internal/special-use IP address
```

**原因分析**: 需进一步分析具体原因

---


### Tool Error (read)

#### 记录 #32

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-14T13:31:15.208Z |
| **文件位置** | `068ac7a06a47c7fdc26656446b63d7e17dc09d94203abb2c92d6bcf41c33f56705d20342347e3b18cfae39e7a2940bae5fb6ca5293e374cbceee772548768613\agents\main\sessions\cda9aafe-3d0a-4cfb-bf9a-40e61755de71.jsonl` |
| **行号** | 7 |

**错误信息**:
```
ENOENT: no such file or directory, access '/app/skills/imap-smtp-email/SKILL.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/app/skills/imap-smtp-email/SKILL.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #33

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-15T05:15:53.568Z |
| **文件位置** | `2839c2f17383d426e0f87c82614743eed21a2aa5a58d39da3b11de6dc56388a31ba9219c47d42da0009bc58633ad7c2f6003d505d1ffb40a96eac87034abf2bf\agents\main\sessions\3b115f85-d481-4522-9123-4f05c4dbf28b.jsonl` |
| **行号** | 7 |

**错误信息**:
```
ENOENT: no such file or directory, access '/app/skills/fetch-news/SKILL.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/app/skills/fetch-news/SKILL.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #34

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-03-30T10:53:56.270Z |
| **文件位置** | `37d31ad6132bab00315c7b7adabe5b839b918500995ce145a03763c66ecc2f612ca90d021c7098f060f5f0547433161ce6af7f6899f2fc1e6f39bab40e12e65a\agents\main\sessions\0af83cd4-10a3-4966-8f3c-2b581a53bf99.jsonl` |
| **行号** | 10 |

**错误信息**:
```
ENOENT: no such file or directory, access '/root/.openclaw/workspace/MEMORY.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/root/.openclaw/workspace/MEMORY.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #35

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-03-30T11:01:30.003Z |
| **文件位置** | `37d31ad6132bab00315c7b7adabe5b839b918500995ce145a03763c66ecc2f612ca90d021c7098f060f5f0547433161ce6af7f6899f2fc1e6f39bab40e12e65a\agents\main\sessions\0af83cd4-10a3-4966-8f3c-2b581a53bf99.jsonl` |
| **行号** | 102 |

**错误信息**:
```
ENOENT: no such file or directory, access '/root/.openclaw/workspace/skills/skill-creator/SKILL.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/root/.openclaw/workspace/skills/skill-creator/SKILL.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #36

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-03T06:03:34.474Z |
| **文件位置** | `6b9ddcdaebe2194da84cac5f43afe06258bad9c39fad6a91b54dccfa0985e2811d3b20e9826838f19020ee5798c0d7ce6a68f9783c75ebcbf64f2051b319bafc\agents\main\sessions\e0ac0499-bef3-4e73-bd9c-fb30bb47ee3d.jsonl` |
| **行号** | 13 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/memory/2026-04-03.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/memory/2026-04-03.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #37

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-13T08:14:56.994Z |
| **文件位置** | `6fca9aa611cf469e15161f2b342062f7c621c962e44d14a57ee1d61d972f9135cd6f8797feb2302283695088f655118edd65a6768f2159207fd01f575a80e207\agents\main\sessions\ecf6d23a-a5ba-4838-a8bc-de4291d68a48.jsonl` |
| **行号** | 83 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/思想汇报.docx'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/思想汇报.docx'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #38

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-08T10:21:29.645Z |
| **文件位置** | `760d501b3400f1a829cfa89ed6a0ef0f1a9e6cb9c5211f9b7ecdcb5a85f3187c9a2b46c53126b6ecccffcf1c3dc914bfce6e8115c5c54c869fec439ab57cf0cd\agents\main\sessions\d1196d3b-7430-4d50-8b08-4bc9a075144b.jsonl` |
| **行号** | 16 |

**错误信息**:
```
ENOENT: no such file or directory, access '/root/.openclaw/models.json'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/root/.openclaw/models.json'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #39

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-10T02:32:00.539Z |
| **文件位置** | `7c557d66ec5e1109b081ae697108c1fc227ca26dfeb29cd9761d0a6e27363a2615b845677d28837b85c7aed72ddf1c45cbedff133f933628c19a8653c9061c97\agents\main\sessions\e751270a-238e-4bfe-8d7a-fb8e9411291d.jsonl` |
| **行号** | 9 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/memory/2026-04-10.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/memory/2026-04-10.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #40

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-10T02:32:00.554Z |
| **文件位置** | `7c557d66ec5e1109b081ae697108c1fc227ca26dfeb29cd9761d0a6e27363a2615b845677d28837b85c7aed72ddf1c45cbedff133f933628c19a8653c9061c97\agents\main\sessions\e751270a-238e-4bfe-8d7a-fb8e9411291d.jsonl` |
| **行号** | 10 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/memory/2026-04-09.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/memory/2026-04-09.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #41

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-10T02:32:00.568Z |
| **文件位置** | `7c557d66ec5e1109b081ae697108c1fc227ca26dfeb29cd9761d0a6e27363a2615b845677d28837b85c7aed72ddf1c45cbedff133f933628c19a8653c9061c97\agents\main\sessions\e751270a-238e-4bfe-8d7a-fb8e9411291d.jsonl` |
| **行号** | 11 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/MEMORY.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/MEMORY.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #42

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-07T08:59:35.099Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\3e109760-5f29-42d7-8c48-6b17464ab9c4.jsonl` |
| **行号** | 23 |

**错误信息**:
```
ENOENT: no such file or directory, access '/root/.openclaw/workspace/memory/2026-04-07.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/root/.openclaw/workspace/memory/2026-04-07.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #43

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-03T08:15:57.256Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\21c20430-e74b-4ea9-8370-5b818e07807f.jsonl` |
| **行号** | 85 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/.learnings/FEATURE_REQUESTS.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/.learnings/FEATURE_REQUESTS.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #44

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-03T06:13:48.468Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\c124a8ac-1e3d-4b27-a6e6-e558938ce159.jsonl` |
| **行号** | 39 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/user.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/user.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #45

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-03T06:13:50.192Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\c124a8ac-1e3d-4b27-a6e6-e558938ce159.jsonl` |
| **行号** | 41 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/user.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/user.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #46

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-15T07:09:55.905Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\55f2f268-0c90-49b6-b2e3-91dc2866807d.jsonl` |
| **行号** | 7 |

**错误信息**:
```
ENOENT: no such file or directory, access '/app/skills/devcdoc-query/SKILL.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/app/skills/devcdoc-query/SKILL.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #47

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-14T09:04:42.829Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\b622c006-2698-4967-9e4c-0a44c6c9457c.jsonl` |
| **行号** | 23 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/cicd/pipeline.py'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/cicd/pipeline.py'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #48

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-07T02:07:27.038Z |
| **文件位置** | `d29befe28f6d1a440997a29a90d297a20ea5c6b0effffb94967c082745c678e4b4efc8f29e2c81246b38e206e09c98183755650d5db5fc6f525f9d8928b67e24\agents\main\sessions\452b6522-ab61-4cb5-9e12-993c22302827.jsonl` |
| **行号** | 23 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/skills/pdf/SKILL.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/skills/pdf/SKILL.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #49

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-07T02:07:33.216Z |
| **文件位置** | `d29befe28f6d1a440997a29a90d297a20ea5c6b0effffb94967c082745c678e4b4efc8f29e2c81246b38e206e09c98183755650d5db5fc6f525f9d8928b67e24\agents\main\sessions\452b6522-ab61-4cb5-9e12-993c22302827.jsonl` |
| **行号** | 25 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/skills/ppt-writer/SKILL.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/skills/ppt-writer/SKILL.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #50

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-02T08:56:50.998Z |
| **文件位置** | `e82a63b4e5707d2608b9934c9266f851b29f2330a215009260a56daa48c47e575bedabfcc33ef2700b5c722e5e32f5f4d0060d4b0a8f13a677754aae776ce452\agents\main\sessions\5a020fba-1343-4725-861a-1083e4ce0105.jsonl` |
| **行号** | 9 |

**错误信息**:
```
ENOENT: no such file or directory, access '/root/.openclaw/workspace/MEMORY.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/root/.openclaw/workspace/MEMORY.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #51

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-02T15:05:11.573Z |
| **文件位置** | `e82a63b4e5707d2608b9934c9266f851b29f2330a215009260a56daa48c47e575bedabfcc33ef2700b5c722e5e32f5f4d0060d4b0a8f13a677754aae776ce452\agents\main\sessions\9fd7e156-e3a7-496e-89e3-84e8611ab65a.jsonl` |
| **行号** | 11 |

**错误信息**:
```
ENOENT: no such file or directory, access '/root/.openclaw/workspace/MEMORY.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/root/.openclaw/workspace/MEMORY.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #52

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-15T01:45:49.493Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 59 |

**错误信息**:
```
ENOENT: no such file or directory, access '/app/docs/README.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/app/docs/README.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #53

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-15T01:47:04.295Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 85 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/MEMORY.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/MEMORY.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #54

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-13T06:38:30.273Z |
| **文件位置** | `fa65c292bbe559bed0e01c9bf4ab7206fea633ad01ff275cb3653e15b8eeb8392f5c407ef79ffee6a7cc913e6e645c52665f51d413888ea1d0a0d252182dc6a8\agents\main\sessions\1911e9d8-ba88-486d-921c-4631f87747df.jsonl` |
| **行号** | 9 |

**错误信息**:
```
ENOENT: no such file or directory, access '/app/skills/policy-search/SKILL.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/app/skills/policy-search/SKILL.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #55

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-13T02:15:17.885Z |
| **文件位置** | `fa65c292bbe559bed0e01c9bf4ab7206fea633ad01ff275cb3653e15b8eeb8392f5c407ef79ffee6a7cc913e6e645c52665f51d413888ea1d0a0d252182dc6a8\agents\main\sessions\8a7a7bbf-e23c-4c9c-bee2-e3b0d0f793dd.jsonl` |
| **行号** | 7 |

**错误信息**:
```
ENOENT: no such file or directory, access '/app/skills/policy-search/SKILL.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/app/skills/policy-search/SKILL.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #56

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-13T02:15:20.685Z |
| **文件位置** | `fa65c292bbe559bed0e01c9bf4ab7206fea633ad01ff275cb3653e15b8eeb8392f5c407ef79ffee6a7cc913e6e645c52665f51d413888ea1d0a0d252182dc6a8\agents\main\sessions\8a7a7bbf-e23c-4c9c-bee2-e3b0d0f793dd.jsonl` |
| **行号** | 11 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/skills/policy-search/SKILL.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/skills/policy-search/SKILL.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #57

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (read) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-13T02:12:58.332Z |
| **文件位置** | `fa65c292bbe559bed0e01c9bf4ab7206fea633ad01ff275cb3653e15b8eeb8392f5c407ef79ffee6a7cc913e6e645c52665f51d413888ea1d0a0d252182dc6a8\agents\main\sessions\dc9038cf-e21f-41ea-98e4-18512d86f492.jsonl` |
| **行号** | 45 |

**错误信息**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/skills/policy-search/SKILL.md'
```

**原始错误**:
```
ENOENT: no such file or directory, access '/home/node/.openclaw/workspace/skills/policy-search/SKILL.md'
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---


### Tool Error (canvas)

#### 记录 #58

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (canvas) |
| **子类型** | error |
| **错误分类** | 缺少必需参数 |
| **时间戳** | 2026-04-13T07:14:36.687Z |
| **文件位置** | `0f8907022d9c7513b586d400ab3c57fb25659eee8f8b5017dd1e9cc094f4ce3a7cc87cb548522993c391f86e956c13838fbfec56464aa0879ce3c468c4aedbdc\agents\main\sessions\2b9f7ba4-e50c-4f33-bf96-85367fa6cebf.jsonl` |
| **行号** | 13 |

**错误信息**:
```
node required
```

**原始错误**:
```
node required
```

**原因分析**: Tool 调用时缺少必需参数

---

#### 记录 #59

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (canvas) |
| **子类型** | error |
| **错误分类** | 缺少必需参数 |
| **时间戳** | 2026-04-13T07:17:43.673Z |
| **文件位置** | `0f8907022d9c7513b586d400ab3c57fb25659eee8f8b5017dd1e9cc094f4ce3a7cc87cb548522993c391f86e956c13838fbfec56464aa0879ce3c468c4aedbdc\agents\main\sessions\2b9f7ba4-e50c-4f33-bf96-85367fa6cebf.jsonl` |
| **行号** | 27 |

**错误信息**:
```
node required
```

**原始错误**:
```
node required
```

**原因分析**: Tool 调用时缺少必需参数

---


### API/Model Error

#### 记录 #60

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | aborted |
| **错误分类** | 请求被中止 |
| **时间戳** | 2026-04-13T08:22:43.126Z |
| **文件位置** | `0f8907022d9c7513b586d400ab3c57fb25659eee8f8b5017dd1e9cc094f4ce3a7cc87cb548522993c391f86e956c13838fbfec56464aa0879ce3c468c4aedbdc\agents\main\sessions\2b9f7ba4-e50c-4f33-bf96-85367fa6cebf.jsonl` |
| **行号** | 68 |

**错误信息**:
```
Request was aborted
```

**原始错误**:
```
Request was aborted
```

**原因分析**: 请求被主动中止，可能是超时或用户取消

---

#### 记录 #61

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | aborted |
| **错误分类** | 请求被中止 |
| **时间戳** | 2026-04-13T08:24:02.174Z |
| **文件位置** | `0f8907022d9c7513b586d400ab3c57fb25659eee8f8b5017dd1e9cc094f4ce3a7cc87cb548522993c391f86e956c13838fbfec56464aa0879ce3c468c4aedbdc\agents\main\sessions\2b9f7ba4-e50c-4f33-bf96-85367fa6cebf.jsonl` |
| **行号** | 72 |

**错误信息**:
```
Request was aborted
```

**原始错误**:
```
Request was aborted
```

**原因分析**: 请求被主动中止，可能是超时或用户取消

---

#### 记录 #62

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T09:11:33.012Z |
| **文件位置** | `13c13153a543ecba2ba0adb5b621795367f9130736913b4d3bbb5b8244184d6163cd24120cba49ff7f7a07a9b5bb27cc263a5db4d6fc3a9b80b2cf24df09952d\agents\main\sessions\b57d8f72-a5ec-4f01-b83b-4c1f823cc564.jsonl` |
| **行号** | 102 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52189 input tokens (16384 > 65536 - 52189). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52189 input tokens (16384 > 65536 - 52189). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #63

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T09:31:33.448Z |
| **文件位置** | `13c13153a543ecba2ba0adb5b621795367f9130736913b4d3bbb5b8244184d6163cd24120cba49ff7f7a07a9b5bb27cc263a5db4d6fc3a9b80b2cf24df09952d\agents\main\sessions\b57d8f72-a5ec-4f01-b83b-4c1f823cc564.jsonl` |
| **行号** | 105 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52195 input tokens (16384 > 65536 - 52195). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52195 input tokens (16384 > 65536 - 52195). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #64

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-16T01:12:45.945Z |
| **文件位置** | `13c13153a543ecba2ba0adb5b621795367f9130736913b4d3bbb5b8244184d6163cd24120cba49ff7f7a07a9b5bb27cc263a5db4d6fc3a9b80b2cf24df09952d\agents\main\sessions\b57d8f72-a5ec-4f01-b83b-4c1f823cc564.jsonl` |
| **行号** | 108 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52317 input tokens (16384 > 65536 - 52317). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52317 input tokens (16384 > 65536 - 52317). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #65

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-16T01:12:48.085Z |
| **文件位置** | `13c13153a543ecba2ba0adb5b621795367f9130736913b4d3bbb5b8244184d6163cd24120cba49ff7f7a07a9b5bb27cc263a5db4d6fc3a9b80b2cf24df09952d\agents\main\sessions\b57d8f72-a5ec-4f01-b83b-4c1f823cc564.jsonl` |
| **行号** | 111 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52617 input tokens (16384 > 65536 - 52617). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52617 input tokens (16384 > 65536 - 52617). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #66

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-16T01:12:49.844Z |
| **文件位置** | `13c13153a543ecba2ba0adb5b621795367f9130736913b4d3bbb5b8244184d6163cd24120cba49ff7f7a07a9b5bb27cc263a5db4d6fc3a9b80b2cf24df09952d\agents\main\sessions\b57d8f72-a5ec-4f01-b83b-4c1f823cc564.jsonl` |
| **行号** | 114 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52738 input tokens (16384 > 65536 - 52738). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52738 input tokens (16384 > 65536 - 52738). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #67

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-16T01:12:51.724Z |
| **文件位置** | `13c13153a543ecba2ba0adb5b621795367f9130736913b4d3bbb5b8244184d6163cd24120cba49ff7f7a07a9b5bb27cc263a5db4d6fc3a9b80b2cf24df09952d\agents\main\sessions\b57d8f72-a5ec-4f01-b83b-4c1f823cc564.jsonl` |
| **行号** | 117 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52859 input tokens (16384 > 65536 - 52859). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52859 input tokens (16384 > 65536 - 52859). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #68

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-03T06:22:54.912Z |
| **文件位置** | `2839c2f17383d426e0f87c82614743eed21a2aa5a58d39da3b11de6dc56388a31ba9219c47d42da0009bc58633ad7c2f6003d505d1ffb40a96eac87034abf2bf\agents\main\sessions\55b3dbad-7082-44c9-8556-9346043c798d.jsonl` |
| **行号** | 38 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 54822 input tokens (16384 > 65536 - 54822). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 54822 input tokens (16384 > 65536 - 54822). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #69

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-03T06:50:47.415Z |
| **文件位置** | `2839c2f17383d426e0f87c82614743eed21a2aa5a58d39da3b11de6dc56388a31ba9219c47d42da0009bc58633ad7c2f6003d505d1ffb40a96eac87034abf2bf\agents\main\sessions\55b3dbad-7082-44c9-8556-9346043c798d.jsonl` |
| **行号** | 40 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 54850 input tokens (16384 > 65536 - 54850). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 54850 input tokens (16384 > 65536 - 54850). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #70

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-03T07:18:27.370Z |
| **文件位置** | `2839c2f17383d426e0f87c82614743eed21a2aa5a58d39da3b11de6dc56388a31ba9219c47d42da0009bc58633ad7c2f6003d505d1ffb40a96eac87034abf2bf\agents\main\sessions\55b3dbad-7082-44c9-8556-9346043c798d.jsonl` |
| **行号** | 42 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 54920 input tokens (16384 > 65536 - 54920). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 54920 input tokens (16384 > 65536 - 54920). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #71

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-03-30T11:59:24.310Z |
| **文件位置** | `37d31ad6132bab00315c7b7adabe5b839b918500995ce145a03763c66ecc2f612ca90d021c7098f060f5f0547433161ce6af7f6899f2fc1e6f39bab40e12e65a\agents\main\sessions\0af83cd4-10a3-4966-8f3c-2b581a53bf99.jsonl` |
| **行号** | 249 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 57546 input tokens (8192 > 65536 - 57546). (parameter=max_token
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 57546 input tokens (8192 > 65536 - 57546). (parameter=max_tokens, value=8192)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #72

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-03-30T12:00:40.495Z |
| **文件位置** | `37d31ad6132bab00315c7b7adabe5b839b918500995ce145a03763c66ecc2f612ca90d021c7098f060f5f0547433161ce6af7f6899f2fc1e6f39bab40e12e65a\agents\main\sessions\0af83cd4-10a3-4966-8f3c-2b581a53bf99.jsonl` |
| **行号** | 251 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 58049 input tokens (8192 > 65536 - 58049). (parameter=max_token
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 58049 input tokens (8192 > 65536 - 58049). (parameter=max_tokens, value=8192)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #73

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-03-30T12:02:07.765Z |
| **文件位置** | `37d31ad6132bab00315c7b7adabe5b839b918500995ce145a03763c66ecc2f612ca90d021c7098f060f5f0547433161ce6af7f6899f2fc1e6f39bab40e12e65a\agents\main\sessions\0af83cd4-10a3-4966-8f3c-2b581a53bf99.jsonl` |
| **行号** | 269 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 57568 input tokens (8192 > 65536 - 57568). (parameter=max_token
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 57568 input tokens (8192 > 65536 - 57568). (parameter=max_tokens, value=8192)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #74

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-03-30T12:36:21.160Z |
| **文件位置** | `37d31ad6132bab00315c7b7adabe5b839b918500995ce145a03763c66ecc2f612ca90d021c7098f060f5f0547433161ce6af7f6899f2fc1e6f39bab40e12e65a\agents\main\sessions\0af83cd4-10a3-4966-8f3c-2b581a53bf99.jsonl` |
| **行号** | 271 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 58542 input tokens (8192 > 65536 - 58542). (parameter=max_token
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 58542 input tokens (8192 > 65536 - 58542). (parameter=max_tokens, value=8192)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #75

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-03-30T12:36:21.617Z |
| **文件位置** | `37d31ad6132bab00315c7b7adabe5b839b918500995ce145a03763c66ecc2f612ca90d021c7098f060f5f0547433161ce6af7f6899f2fc1e6f39bab40e12e65a\agents\main\sessions\0af83cd4-10a3-4966-8f3c-2b581a53bf99.jsonl` |
| **行号** | 273 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 58834 input tokens (8192 > 65536 - 58834). (parameter=max_token
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 58834 input tokens (8192 > 65536 - 58834). (parameter=max_tokens, value=8192)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #76

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | 模型名称无效 |
| **时间戳** | 2026-04-13T06:13:30.457Z |
| **文件位置** | `6fca9aa611cf469e15161f2b342062f7c621c962e44d14a57ee1d61d972f9135cd6f8797feb2302283695088f655118edd65a6768f2159207fd01f575a80e207\agents\main\sessions\ecf6d23a-a5ba-4838-a8bc-de4291d68a48.jsonl` |
| **行号** | 40 |

**错误信息**:
```
400 {'error': '/chat/completions: Invalid model name passed in model=AIAPLLM-vision-nothink. Call `/v1/models` to view available models for your key.'}
```

**原始错误**:
```
400 {'error': '/chat/completions: Invalid model name passed in model=AIAPLLM-vision-nothink. Call `/v1/models` to view available models for your key.'}
```

**原因分析**: 配置的模型名称在 API 中不存在或不可用

---

#### 记录 #77

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | 模型名称无效 |
| **时间戳** | 2026-04-13T06:14:13.557Z |
| **文件位置** | `6fca9aa611cf469e15161f2b342062f7c621c962e44d14a57ee1d61d972f9135cd6f8797feb2302283695088f655118edd65a6768f2159207fd01f575a80e207\agents\main\sessions\ecf6d23a-a5ba-4838-a8bc-de4291d68a48.jsonl` |
| **行号** | 42 |

**错误信息**:
```
400 {'error': '/chat/completions: Invalid model name passed in model=AIAPLLM-vision-nothink. Call `/v1/models` to view available models for your key.'}
```

**原始错误**:
```
400 {'error': '/chat/completions: Invalid model name passed in model=AIAPLLM-vision-nothink. Call `/v1/models` to view available models for your key.'}
```

**原因分析**: 配置的模型名称在 API 中不存在或不可用

---

#### 记录 #78

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | 上游连接错误 |
| **时间戳** | 2026-03-25T05:25:08.052Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 6 |

**错误信息**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原始错误**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原因分析**: 模型服务连接失败，可能是网络延迟、服务宕机或防火墙阻止连接

---

#### 记录 #79

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | 上游连接错误 |
| **时间戳** | 2026-03-25T05:25:11.504Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 7 |

**错误信息**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原始错误**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原因分析**: 模型服务连接失败，可能是网络延迟、服务宕机或防火墙阻止连接

---

#### 记录 #80

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | 上游连接错误 |
| **时间戳** | 2026-03-25T05:25:16.991Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 8 |

**错误信息**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原始错误**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原因分析**: 模型服务连接失败，可能是网络延迟、服务宕机或防火墙阻止连接

---

#### 记录 #81

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | 上游连接错误 |
| **时间戳** | 2026-03-25T05:25:26.271Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 9 |

**错误信息**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原始错误**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原因分析**: 模型服务连接失败，可能是网络延迟、服务宕机或防火墙阻止连接

---

#### 记录 #82

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | 上游连接错误 |
| **时间戳** | 2026-03-25T05:25:49.595Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 11 |

**错误信息**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原始错误**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原因分析**: 模型服务连接失败，可能是网络延迟、服务宕机或防火墙阻止连接

---

#### 记录 #83

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | 上游连接错误 |
| **时间戳** | 2026-03-25T05:25:53.195Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 12 |

**错误信息**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原始错误**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原因分析**: 模型服务连接失败，可能是网络延迟、服务宕机或防火墙阻止连接

---

#### 记录 #84

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | 上游连接错误 |
| **时间戳** | 2026-03-25T05:25:58.663Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 13 |

**错误信息**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原始错误**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原因分析**: 模型服务连接失败，可能是网络延迟、服务宕机或防火墙阻止连接

---

#### 记录 #85

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | 上游连接错误 |
| **时间戳** | 2026-03-25T05:26:08.147Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 14 |

**错误信息**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原始错误**:
```
503 upstream connect error or disconnect/reset before headers. reset reason: remote connection failure, transport failure reason: delayed connect error: 111
```

**原因分析**: 模型服务连接失败，可能是网络延迟、服务宕机或防火墙阻止连接

---

#### 记录 #86

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-03-26T01:53:01.595Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 244 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 57554 input tokens (8192 > 65536 - 57554). (parameter=max_token
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 57554 input tokens (8192 > 65536 - 57554). (parameter=max_tokens, value=8192)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #87

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-03-26T02:00:40.558Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 246 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 57852 input tokens (8192 > 65536 - 57852). (parameter=max_token
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 57852 input tokens (8192 > 65536 - 57852). (parameter=max_tokens, value=8192)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #88

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-03-26T02:01:46.469Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 248 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 58165 input tokens (8192 > 65536 - 58165). (parameter=max_token
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 58165 input tokens (8192 > 65536 - 58165). (parameter=max_tokens, value=8192)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #89

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-03-26T02:01:46.893Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 250 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 57910 input tokens (8192 > 65536 - 57910). (parameter=max_token
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 57910 input tokens (8192 > 65536 - 57910). (parameter=max_tokens, value=8192)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #90

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-03T09:15:16.986Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\21c20430-e74b-4ea9-8370-5b818e07807f.jsonl` |
| **行号** | 116 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50053 input tokens (16384 > 65536 - 50053). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50053 input tokens (16384 > 65536 - 50053). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #91

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | 上游连接错误 |
| **时间戳** | 2026-04-03T09:17:19.445Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\21c20430-e74b-4ea9-8370-5b818e07807f.jsonl` |
| **行号** | 118 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50321 input tokens (16384 > 65536 - 50321). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50321 input tokens (16384 > 65536 - 50321). (parameter=max_tokens, value=16384)
```

**原因分析**: 模型服务连接失败，可能是网络延迟、服务宕机或防火墙阻止连接

---

#### 记录 #92

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-03T09:32:46.406Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\21c20430-e74b-4ea9-8370-5b818e07807f.jsonl` |
| **行号** | 120 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50589 input tokens (16384 > 65536 - 50589). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50589 input tokens (16384 > 65536 - 50589). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #93

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T07:18:49.508Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\57655182-1fa9-4dca-aafc-f16e69319ef6.jsonl` |
| **行号** | 8 |

**错误信息**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 93196 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=93196)
```

**原始错误**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 93196 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=93196)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #94

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T07:05:53.732Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\9ccfae6c-1ba2-4215-b07c-f16eebaee938.jsonl` |
| **行号** | 8 |

**错误信息**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 92360 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=92360)
```

**原始错误**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 92360 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=92360)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #95

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | aborted |
| **错误分类** | 请求被中止 |
| **时间戳** | 2026-04-03T06:23:38.196Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\c124a8ac-1e3d-4b27-a6e6-e558938ce159.jsonl` |
| **行号** | 94 |

**错误信息**:
```
Request was aborted
```

**原始错误**:
```
Request was aborted
```

**原因分析**: 请求被主动中止，可能是超时或用户取消

---

#### 记录 #96

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-03T06:45:38.126Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\c124a8ac-1e3d-4b27-a6e6-e558938ce159.jsonl` |
| **行号** | 144 |

**错误信息**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 73149 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=73149)
```

**原始错误**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 73149 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=73149)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #97

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-03T07:01:02.066Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\c124a8ac-1e3d-4b27-a6e6-e558938ce159.jsonl` |
| **行号** | 146 |

**错误信息**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 73204 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=73204)
```

**原始错误**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 73204 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=73204)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #98

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-03T07:13:44.537Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\c124a8ac-1e3d-4b27-a6e6-e558938ce159.jsonl` |
| **行号** | 148 |

**错误信息**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 73462 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=73462)
```

**原始错误**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 73462 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=73462)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #99

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T07:06:12.385Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\f15427eb-5cbe-4649-b5e5-ff97dbf69934.jsonl` |
| **行号** | 8 |

**错误信息**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 92483 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=92483)
```

**原始错误**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 92483 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=92483)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #100

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T06:24:52.873Z |
| **文件位置** | `a995c7a073fd97cd533a17b62717f0d48e1c6a2d3597fb0668c16564788bde06a2ca13b88f6f674596a9d3f0ae0194307a36103251a8b8cc2ac7cbcc8717ee82\agents\main\sessions\8e991737-22bf-448e-8bbe-c62186c39811.jsonl` |
| **行号** | 40 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 51784 input tokens (16384 > 65536 - 51784). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 51784 input tokens (16384 > 65536 - 51784). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #101

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T05:15:50.271Z |
| **文件位置** | `a995c7a073fd97cd533a17b62717f0d48e1c6a2d3597fb0668c16564788bde06a2ca13b88f6f674596a9d3f0ae0194307a36103251a8b8cc2ac7cbcc8717ee82\agents\main\sessions\c4600d75-8dd6-4f40-814c-a0ce5cbfbc5e.jsonl` |
| **行号** | 10 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 64170 input tokens (16384 > 65536 - 64170). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 64170 input tokens (16384 > 65536 - 64170). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #102

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T05:17:31.594Z |
| **文件位置** | `a995c7a073fd97cd533a17b62717f0d48e1c6a2d3597fb0668c16564788bde06a2ca13b88f6f674596a9d3f0ae0194307a36103251a8b8cc2ac7cbcc8717ee82\agents\main\sessions\c4600d75-8dd6-4f40-814c-a0ce5cbfbc5e.jsonl` |
| **行号** | 13 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 64329 input tokens (16384 > 65536 - 64329). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 64329 input tokens (16384 > 65536 - 64329). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #103

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T05:17:56.401Z |
| **文件位置** | `a995c7a073fd97cd533a17b62717f0d48e1c6a2d3597fb0668c16564788bde06a2ca13b88f6f674596a9d3f0ae0194307a36103251a8b8cc2ac7cbcc8717ee82\agents\main\sessions\c4600d75-8dd6-4f40-814c-a0ce5cbfbc5e.jsonl` |
| **行号** | 16 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 64391 input tokens (16384 > 65536 - 64391). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 64391 input tokens (16384 > 65536 - 64391). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #104

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T05:17:58.646Z |
| **文件位置** | `a995c7a073fd97cd533a17b62717f0d48e1c6a2d3597fb0668c16564788bde06a2ca13b88f6f674596a9d3f0ae0194307a36103251a8b8cc2ac7cbcc8717ee82\agents\main\sessions\c4600d75-8dd6-4f40-814c-a0ce5cbfbc5e.jsonl` |
| **行号** | 19 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 64453 input tokens (16384 > 65536 - 64453). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 64453 input tokens (16384 > 65536 - 64453). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #105

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T05:18:00.910Z |
| **文件位置** | `a995c7a073fd97cd533a17b62717f0d48e1c6a2d3597fb0668c16564788bde06a2ca13b88f6f674596a9d3f0ae0194307a36103251a8b8cc2ac7cbcc8717ee82\agents\main\sessions\c4600d75-8dd6-4f40-814c-a0ce5cbfbc5e.jsonl` |
| **行号** | 22 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 64515 input tokens (16384 > 65536 - 64515). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 64515 input tokens (16384 > 65536 - 64515). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #106

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T05:18:02.611Z |
| **文件位置** | `a995c7a073fd97cd533a17b62717f0d48e1c6a2d3597fb0668c16564788bde06a2ca13b88f6f674596a9d3f0ae0194307a36103251a8b8cc2ac7cbcc8717ee82\agents\main\sessions\c4600d75-8dd6-4f40-814c-a0ce5cbfbc5e.jsonl` |
| **行号** | 25 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 64577 input tokens (16384 > 65536 - 64577). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 64577 input tokens (16384 > 65536 - 64577). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #107

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:04:07.147Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 113 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 51191 input tokens (16384 > 65536 - 51191). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 51191 input tokens (16384 > 65536 - 51191). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #108

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:11:40.120Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 149 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 49625 input tokens (16384 > 65536 - 49625). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 49625 input tokens (16384 > 65536 - 49625). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #109

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:11:41.959Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 152 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 49635 input tokens (16384 > 65536 - 49635). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 49635 input tokens (16384 > 65536 - 49635). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #110

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:11:43.993Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 155 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50137 input tokens (16384 > 65536 - 50137). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50137 input tokens (16384 > 65536 - 50137). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #111

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:11:46.324Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 158 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 51119 input tokens (16384 > 65536 - 51119). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 51119 input tokens (16384 > 65536 - 51119). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #112

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:11:48.360Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 161 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 51677 input tokens (16384 > 65536 - 51677). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 51677 input tokens (16384 > 65536 - 51677). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #113

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:11:51.942Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 164 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52235 input tokens (16384 > 65536 - 52235). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52235 input tokens (16384 > 65536 - 52235). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #114

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:11:53.787Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 167 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 51945 input tokens (16384 > 65536 - 51945). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 51945 input tokens (16384 > 65536 - 51945). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #115

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:11:56.038Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 170 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52954 input tokens (16384 > 65536 - 52954). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 52954 input tokens (16384 > 65536 - 52954). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #116

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:11:58.063Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 173 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 53315 input tokens (16384 > 65536 - 53315). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 53315 input tokens (16384 > 65536 - 53315). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #117

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:12:00.091Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 176 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 53676 input tokens (16384 > 65536 - 53676). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 53676 input tokens (16384 > 65536 - 53676). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #118

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:12:02.226Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 179 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 53166 input tokens (16384 > 65536 - 53166). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 53166 input tokens (16384 > 65536 - 53166). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #119

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:12:04.694Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 182 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 54424 input tokens (16384 > 65536 - 54424). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 54424 input tokens (16384 > 65536 - 54424). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #120

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:12:06.970Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 185 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 54798 input tokens (16384 > 65536 - 54798). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 54798 input tokens (16384 > 65536 - 54798). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #121

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:12:09.210Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 188 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 55172 input tokens (16384 > 65536 - 55172). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 55172 input tokens (16384 > 65536 - 55172). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #122

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:20:57.903Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 191 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 54355 input tokens (16384 > 65536 - 54355). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 54355 input tokens (16384 > 65536 - 54355). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #123

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:21:00.619Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 194 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 55606 input tokens (16384 > 65536 - 55606). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 55606 input tokens (16384 > 65536 - 55606). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #124

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:21:02.413Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 197 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 55737 input tokens (16384 > 65536 - 55737). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 55737 input tokens (16384 > 65536 - 55737). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #125

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-14T09:21:04.194Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 200 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 55868 input tokens (16384 > 65536 - 55868). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 55868 input tokens (16384 > 65536 - 55868). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #126

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-07T02:07:42.220Z |
| **文件位置** | `d29befe28f6d1a440997a29a90d297a20ea5c6b0effffb94967c082745c678e4b4efc8f29e2c81246b38e206e09c98183755650d5db5fc6f525f9d8928b67e24\agents\main\sessions\452b6522-ab61-4cb5-9e12-993c22302827.jsonl` |
| **行号** | 38 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 53947 input tokens (16384 > 65536 - 53947). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 53947 input tokens (16384 > 65536 - 53947). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #127

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-03-31T09:25:55.791Z |
| **文件位置** | `e82a63b4e5707d2608b9934c9266f851b29f2330a215009260a56daa48c47e575bedabfcc33ef2700b5c722e5e32f5f4d0060d4b0a8f13a677754aae776ce452\agents\main\sessions\5a7e6f9d-4c43-4a9a-820e-5ba304317da6.jsonl` |
| **行号** | 121 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 57883 input tokens (8192 > 65536 - 57883). (parameter=max_token
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 57883 input tokens (8192 > 65536 - 57883). (parameter=max_tokens, value=8192)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #128

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-03-31T09:26:11.341Z |
| **文件位置** | `e82a63b4e5707d2608b9934c9266f851b29f2330a215009260a56daa48c47e575bedabfcc33ef2700b5c722e5e32f5f4d0060d4b0a8f13a677754aae776ce452\agents\main\sessions\5a7e6f9d-4c43-4a9a-820e-5ba304317da6.jsonl` |
| **行号** | 123 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 58180 input tokens (8192 > 65536 - 58180). (parameter=max_token
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 58180 input tokens (8192 > 65536 - 58180). (parameter=max_tokens, value=8192)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #129

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-03-31T09:26:11.662Z |
| **文件位置** | `e82a63b4e5707d2608b9934c9266f851b29f2330a215009260a56daa48c47e575bedabfcc33ef2700b5c722e5e32f5f4d0060d4b0a8f13a677754aae776ce452\agents\main\sessions\5a7e6f9d-4c43-4a9a-820e-5ba304317da6.jsonl` |
| **行号** | 125 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 58297 input tokens (8192 > 65536 - 58297). (parameter=max_token
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 8192. This model's maximum context length is 65536 tokens and your request has 58297 input tokens (8192 > 65536 - 58297). (parameter=max_tokens, value=8192)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #130

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | aborted |
| **错误分类** | 请求被中止 |
| **时间戳** | 2026-04-15T01:44:18.906Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 38 |

**错误信息**:
```
Request was aborted
```

**原始错误**:
```
Request was aborted
```

**原因分析**: 请求被主动中止，可能是超时或用户取消

---

#### 记录 #131

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T01:56:58.502Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 118 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 49813 input tokens (16384 > 65536 - 49813). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 49813 input tokens (16384 > 65536 - 49813). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #132

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T01:58:42.863Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 121 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 49935 input tokens (16384 > 65536 - 49935). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 49935 input tokens (16384 > 65536 - 49935). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #133

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T01:59:10.369Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 124 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50012 input tokens (16384 > 65536 - 50012). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50012 input tokens (16384 > 65536 - 50012). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #134

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T01:59:14.608Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 127 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50089 input tokens (16384 > 65536 - 50089). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50089 input tokens (16384 > 65536 - 50089). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #135

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T01:59:17.769Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 130 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50166 input tokens (16384 > 65536 - 50166). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50166 input tokens (16384 > 65536 - 50166). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #136

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-15T01:59:19.899Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 133 |

**错误信息**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50243 input tokens (16384 > 65536 - 50243). (parameter=max_tok
```

**原始错误**:
```
400 'max_tokens' or 'max_completion_tokens' is too large: 16384. This model's maximum context length is 65536 tokens and your request has 50243 input tokens (16384 > 65536 - 50243). (parameter=max_tokens, value=16384)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---

#### 记录 #137

| 字段 | 内容 |
|------|------|
| **错误类型** | API/Model Error |
| **子类型** | error |
| **错误分类** | Token 超限错误 |
| **时间戳** | 2026-04-13T02:18:17.058Z |
| **文件位置** | `fa65c292bbe559bed0e01c9bf4ab7206fea633ad01ff275cb3653e15b8eeb8392f5c407ef79ffee6a7cc913e6e645c52665f51d413888ea1d0a0d252182dc6a8\agents\main\sessions\8a7a7bbf-e23c-4c9c-bee2-e3b0d0f793dd.jsonl` |
| **行号** | 38 |

**错误信息**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 93398 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=93398)
```

**原始错误**:
```
400 This model's maximum context length is 65536 tokens. However, your request has 93398 input tokens. Please reduce the length of the input messages. (parameter=input_tokens, value=93398)
```

**原因分析**: 对话历史过长导致 token 数超过模型上下文限制，需要 truncation 或清理历史

---


### Tool Error (edit)

#### 记录 #138

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (edit) |
| **子类型** | error |
| **错误分类** | 缺少必需参数 |
| **时间戳** | 2026-03-30T11:18:01.391Z |
| **文件位置** | `37d31ad6132bab00315c7b7adabe5b839b918500995ce145a03763c66ecc2f612ca90d021c7098f060f5f0547433161ce6af7f6899f2fc1e6f39bab40e12e65a\agents\main\sessions\0af83cd4-10a3-4966-8f3c-2b581a53bf99.jsonl` |
| **行号** | 161 |

**错误信息**:
```
Missing required parameter: oldText (oldText or old_string). Supply correct parameters before retrying.
```

**原始错误**:
```
Missing required parameter: oldText (oldText or old_string). Supply correct parameters before retrying.
```

**原因分析**: Tool 调用时缺少必需参数

---

#### 记录 #139

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (edit) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-03T07:17:39.239Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\21c20430-e74b-4ea9-8370-5b818e07807f.jsonl` |
| **行号** | 57 |

**错误信息**:
```
EROFS: read-only file system, open '/home/node/.openclaw/workspace/USER.md'
```

**原始错误**:
```
EROFS: read-only file system, open '/home/node/.openclaw/workspace/USER.md'
```

**原因分析**: 需进一步分析具体原因

---

#### 记录 #140

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (edit) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-03T06:24:23.894Z |
| **文件位置** | `a793d94b6ad1c388bc785ea54e450926b729a9ed21fd7f5685e549542317b191889efa017a1d6c1cea1b952519ba7f227fe5499937e9452e032463addb26e3de\agents\main\sessions\c124a8ac-1e3d-4b27-a6e6-e558938ce159.jsonl` |
| **行号** | 97 |

**错误信息**:
```
EROFS: read-only file system, open '/home/node/.openclaw/workspace/USER.md'
```

**原始错误**:
```
EROFS: read-only file system, open '/home/node/.openclaw/workspace/USER.md'
```

**原因分析**: 需进一步分析具体原因

---

#### 记录 #141

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (edit) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-15T01:37:32.432Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\d6a1d780-5b49-4bef-ae4e-532a97fe45e3.jsonl` |
| **行号** | 26 |

**错误信息**:
```
Could not find edits[1] in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The oldText must match exactly including all whitespace and newlines.
```

**原始错误**:
```
Could not find edits[1] in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The oldText must match exactly including all whitespace and newlines.
```

**原因分析**: 需进一步分析具体原因

---

#### 记录 #142

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (edit) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-15T01:38:03.727Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\d6a1d780-5b49-4bef-ae4e-532a97fe45e3.jsonl` |
| **行号** | 32 |

**错误信息**:
```
Could not find the exact text in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The old text must match exactly including all whitespace and newlines.
Current file contents:
import json

```

**原始错误**:
```
Could not find the exact text in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The old text must match exactly including all whitespace and newlines.
Current file contents:
import json
import logging
import subprocess
import traceback

from sharelib.ci.CIbase import CIbase
from sharelib.driver.Utils import Utils
from sharelib.driver.Yunxiao import Yunxiao
from sharelib.driver.codetools.VerifyPom import VerfiyPom
from sharelib.handler.InterCusStep import InterCusStep


# 配置 logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


class CIcommon(CIbase):
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        super().__init__(**kwargs)
        self.conf = kwargs.get("conf")
        self.appname = self.envmap.get("CI_SOURCE_NAME")
        self.gitdata = self.get_git_data()
        self.csystem = self.envmap.get("
... (truncated)
```

**原因分析**: 需进一步分析具体原因

---

#### 记录 #143

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (edit) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-15T01:38:10.204Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\d6a1d780-5b49-4bef-ae4e-532a97fe45e3.jsonl` |
| **行号** | 34 |

**错误信息**:
```
Could not find edits[4] in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The oldText must match exactly including all whitespace and newlines.
```

**原始错误**:
```
Could not find edits[4] in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The oldText must match exactly including all whitespace and newlines.
```

**原因分析**: 需进一步分析具体原因

---

#### 记录 #144

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (edit) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-15T01:38:18.032Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\d6a1d780-5b49-4bef-ae4e-532a97fe45e3.jsonl` |
| **行号** | 44 |

**错误信息**:
```
Could not find the exact text in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The old text must match exactly including all whitespace and newlines.
Current file contents:
import json

```

**原始错误**:
```
Could not find the exact text in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The old text must match exactly including all whitespace and newlines.
Current file contents:
import json
import logging
import subprocess
import traceback

from sharelib.ci.CIbase import CIbase
from sharelib.driver.Utils import Utils
from sharelib.driver.Yunxiao import Yunxiao
from sharelib.driver.codetools.VerifyPom import VerfiyPom
from sharelib.handler.InterCusStep import InterCusStep


# 配置 logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


class CIcommon(CIbase):
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        super().__init__(**kwargs)
        self.conf = kwargs.get("conf")
        self.appname = self.envmap.get("CI_SOURCE_NAME")
        self.gitdata = self.get_git_data()
        self.csystem = self.envmap.get("
... (truncated)
```

**原因分析**: 需进一步分析具体原因

---

#### 记录 #145

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (edit) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-15T01:38:22.216Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\d6a1d780-5b49-4bef-ae4e-532a97fe45e3.jsonl` |
| **行号** | 50 |

**错误信息**:
```
Could not find the exact text in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The old text must match exactly including all whitespace and newlines.
Current file contents:
import json

```

**原始错误**:
```
Could not find the exact text in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The old text must match exactly including all whitespace and newlines.
Current file contents:
import json
import logging
import subprocess
import traceback

from sharelib.ci.CIbase import CIbase
from sharelib.driver.Utils import Utils
from sharelib.driver.Yunxiao import Yunxiao
from sharelib.driver.codetools.VerifyPom import VerfiyPom
from sharelib.handler.InterCusStep import InterCusStep


# 配置 logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


class CIcommon(CIbase):
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        super().__init__(**kwargs)
        self.conf = kwargs.get("conf")
        self.appname = self.envmap.get("CI_SOURCE_NAME")
        self.gitdata = self.get_git_data()
        self.csystem = self.envmap.get("
... (truncated)
```

**原因分析**: 需进一步分析具体原因

---

#### 记录 #146

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (edit) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-15T01:38:38.189Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\d6a1d780-5b49-4bef-ae4e-532a97fe45e3.jsonl` |
| **行号** | 68 |

**错误信息**:
```
Could not find the exact text in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The old text must match exactly including all whitespace and newlines.
Current file contents:
import json

```

**原始错误**:
```
Could not find the exact text in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The old text must match exactly including all whitespace and newlines.
Current file contents:
import json
import logging
import subprocess
import traceback

from sharelib.ci.CIbase import CIbase
from sharelib.driver.Utils import Utils
from sharelib.driver.Yunxiao import Yunxiao
from sharelib.driver.codetools.VerifyPom import VerfiyPom
from sharelib.handler.InterCusStep import InterCusStep


# 配置 logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


class CIcommon(CIbase):
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        super().__init__(**kwargs)
        self.conf = kwargs.get("conf")
        self.appname = self.envmap.get("CI_SOURCE_NAME")
        self.gitdata = self.get_git_data()
        self.csystem = self.envmap.get("
... (truncated)
```

**原因分析**: 需进一步分析具体原因

---

#### 记录 #147

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (edit) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-15T01:38:51.711Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\d6a1d780-5b49-4bef-ae4e-532a97fe45e3.jsonl` |
| **行号** | 80 |

**错误信息**:
```
Could not find the exact text in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The old text must match exactly including all whitespace and newlines.
Current file contents:
import json

```

**原始错误**:
```
Could not find the exact text in /home/node/.openclaw/workspace/cicd/sharelib/ci/CIcommon.py. The old text must match exactly including all whitespace and newlines.
Current file contents:
import json
import logging
import subprocess
import traceback

from sharelib.ci.CIbase import CIbase
from sharelib.driver.Utils import Utils
from sharelib.driver.Yunxiao import Yunxiao
from sharelib.driver.codetools.VerifyPom import VerfiyPom
from sharelib.handler.InterCusStep import InterCusStep


# 配置 logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


class CIcommon(CIbase):
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        super().__init__(**kwargs)
        self.conf = kwargs.get("conf")
        self.appname = self.envmap.get("CI_SOURCE_NAME")
        self.gitdata = self.get_git_data()
        self.csystem = self.envmap.get("
... (truncated)
```

**原因分析**: 需进一步分析具体原因

---


### Tool Error (cron)

#### 记录 #148

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (cron) |
| **子类型** | error |
| **错误分类** | 定时任务配置错误 |
| **时间戳** | 2026-04-13T04:49:31.892Z |
| **文件位置** | `6fca9aa611cf469e15161f2b342062f7c621c962e44d14a57ee1d61d972f9135cd6f8797feb2302283695088f655118edd65a6768f2159207fd01f575a80e207\agents\main\sessions\ecf6d23a-a5ba-4838-a8bc-de4291d68a48.jsonl` |
| **行号** | 7 |

**错误信息**:
```
Error: cron channel delivery config is only supported for sessionTarget="isolated"
```

**原始错误**:
```
Error: cron channel delivery config is only supported for sessionTarget="isolated"
```

**原因分析**: 定时任务配置不正确，需要检查 sessionTarget 和 payload.kind 设置

---

#### 记录 #149

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (cron) |
| **子类型** | error |
| **错误分类** | 定时任务配置错误 |
| **时间戳** | 2026-04-13T04:49:34.071Z |
| **文件位置** | `6fca9aa611cf469e15161f2b342062f7c621c962e44d14a57ee1d61d972f9135cd6f8797feb2302283695088f655118edd65a6768f2159207fd01f575a80e207\agents\main\sessions\ecf6d23a-a5ba-4838-a8bc-de4291d68a48.jsonl` |
| **行号** | 9 |

**错误信息**:
```
Error: isolated/current/session cron jobs require payload.kind="agentTurn"
```

**原始错误**:
```
Error: isolated/current/session cron jobs require payload.kind="agentTurn"
```

**原因分析**: 定时任务配置不正确，需要检查 sessionTarget 和 payload.kind 设置

---

#### 记录 #150

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (cron) |
| **子类型** | error |
| **错误分类** | 缺少必需参数 |
| **时间戳** | 2026-04-15T01:56:37.118Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 93 |

**错误信息**:
```
text required
```

**原始错误**:
```
text required
```

**原因分析**: Tool 调用时缺少必需参数

---


### Tool Error (gateway)

#### 记录 #151

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (gateway) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-13T06:11:36.851Z |
| **文件位置** | `6fca9aa611cf469e15161f2b342062f7c621c962e44d14a57ee1d61d972f9135cd6f8797feb2302283695088f655118edd65a6768f2159207fd01f575a80e207\agents\main\sessions\ecf6d23a-a5ba-4838-a8bc-de4291d68a48.jsonl` |
| **行号** | 25 |

**错误信息**:
```
config schema path not found
```

**原始错误**:
```
config schema path not found
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---

#### 记录 #152

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (gateway) |
| **子类型** | error |
| **错误分类** | JSON 解析错误 |
| **时间戳** | 2026-04-13T06:11:41.825Z |
| **文件位置** | `6fca9aa611cf469e15161f2b342062f7c621c962e44d14a57ee1d61d972f9135cd6f8797feb2302283695088f655118edd65a6768f2159207fd01f575a80e207\agents\main\sessions\ecf6d23a-a5ba-4838-a8bc-de4291d68a48.jsonl` |
| **行号** | 29 |

**错误信息**:
```
SyntaxError: JSON5: invalid character 'h' at 1:1
```

**原始错误**:
```
SyntaxError: JSON5: invalid character 'h' at 1:1
```

**原因分析**: 配置文件 JSON 格式错误

---

#### 记录 #153

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (gateway) |
| **子类型** | error |
| **错误分类** | 缺少必需参数 |
| **时间戳** | 2026-04-13T06:11:44.177Z |
| **文件位置** | `6fca9aa611cf469e15161f2b342062f7c621c962e44d14a57ee1d61d972f9135cd6f8797feb2302283695088f655118edd65a6768f2159207fd01f575a80e207\agents\main\sessions\ecf6d23a-a5ba-4838-a8bc-de4291d68a48.jsonl` |
| **行号** | 31 |

**错误信息**:
```
raw required
```

**原始错误**:
```
raw required
```

**原因分析**: Tool 调用时缺少必需参数

---

#### 记录 #154

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (gateway) |
| **子类型** | error |
| **错误分类** | 缺少必需参数 |
| **时间戳** | 2026-03-25T05:28:22.446Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 21 |

**错误信息**:
```
raw required
```

**原始错误**:
```
raw required
```

**原因分析**: Tool 调用时缺少必需参数

---

#### 记录 #155

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (gateway) |
| **子类型** | error |
| **错误分类** | 文件/资源未找到 |
| **时间戳** | 2026-04-14T06:12:09.468Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\0f678300-9756-4ea9-b283-9cf231eaba5f.jsonl` |
| **行号** | 9 |

**错误信息**:
```
config schema path not found
```

**原始错误**:
```
config schema path not found
```

**原因分析**: 请求的文件或 Skill 不存在，可能是未正确安装或路径配置错误

---


### Tool Error (unknown)

#### 记录 #156

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (unknown) |
| **子类型** | forbidden |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-03-25T05:34:51.789Z |
| **文件位置** | `902b55f3e6f72c412522719af72c4a67a6809d8f908c19bdf409d68941942599c5f008b7a7a2170f407ad283504b75e2efdffcdd4e98826974fcaa621e929062\agents\main\sessions\38cb43c3-64cc-47c2-8ad0-9752d31a0c95.jsonl` |
| **行号** | 61 |

**错误信息**:
```
agentId is not allowed for sessions_spawn (allowed: none)
```

**原始错误**:
```
agentId is not allowed for sessions_spawn (allowed: none)
```

**原因分析**: 需进一步分析具体原因

---

#### 记录 #157

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (unknown) |
| **子类型** | error |
| **错误分类** | 缺少必需参数 |
| **时间戳** | 2026-04-15T06:24:15.620Z |
| **文件位置** | `a995c7a073fd97cd533a17b62717f0d48e1c6a2d3597fb0668c16564788bde06a2ca13b88f6f674596a9d3f0ae0194307a36103251a8b8cc2ac7cbcc8717ee82\agents\main\sessions\8e991737-22bf-448e-8bbe-c62186c39811.jsonl` |
| **行号** | 13 |

**错误信息**:
```
gateway closed (1008): pairing required
Gateway target: ws://127.0.0.1:18789
Source: local loopback
Config: /home/node/.openclaw/openclaw.json
Bind: lan
```

**原始错误**:
```
gateway closed (1008): pairing required
Gateway target: ws://127.0.0.1:18789
Source: local loopback
Config: /home/node/.openclaw/openclaw.json
Bind: lan
```

**原因分析**: Tool 调用时缺少必需参数

---

#### 记录 #158

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (unknown) |
| **子类型** | error |
| **错误分类** | 缺少必需参数 |
| **时间戳** | 2026-04-15T01:45:27.554Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 41 |

**错误信息**:
```
gateway closed (1008): pairing required
Gateway target: ws://127.0.0.1:18789
Source: local loopback
Config: /home/node/.openclaw/openclaw.json
Bind: lan
```

**原始错误**:
```
gateway closed (1008): pairing required
Gateway target: ws://127.0.0.1:18789
Source: local loopback
Config: /home/node/.openclaw/openclaw.json
Bind: lan
```

**原因分析**: Tool 调用时缺少必需参数

---

#### 记录 #159

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (unknown) |
| **子类型** | error |
| **错误分类** | 缺少必需参数 |
| **时间戳** | 2026-04-15T01:56:35.907Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 91 |

**错误信息**:
```
gateway closed (1008): pairing required
Gateway target: ws://127.0.0.1:18789
Source: local loopback
Config: /home/node/.openclaw/openclaw.json
Bind: lan
```

**原始错误**:
```
gateway closed (1008): pairing required
Gateway target: ws://127.0.0.1:18789
Source: local loopback
Config: /home/node/.openclaw/openclaw.json
Bind: lan
```

**原因分析**: Tool 调用时缺少必需参数

---

#### 记录 #160

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (unknown) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-15T01:56:53.035Z |
| **文件位置** | `f222336474c3c33b45b015cca3fdcf24fbfc8a597f351d79bc150829f53504e5d7819658cde4a8f7af659e260af6be27b33dcadf21b2b5928bbdc265681b3e6d\agents\main\sessions\8ef546cf-18a4-43a7-baec-ed0207c28996.jsonl` |
| **行号** | 109 |

**错误信息**:
```
No session found with label: 安装 k8s-pilot 技能
```

**原始错误**:
```
No session found with label: 安装 k8s-pilot 技能
```

**原因分析**: 需进一步分析具体原因

---


### Tool Error (nodes)

#### 记录 #161

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (nodes) |
| **子类型** | error |
| **错误分类** | 缺少必需参数 |
| **时间戳** | 2026-04-15T09:57:18.490Z |
| **文件位置** | `b487297d6f8f74a2f1bced0cfbb32195bbbe3294ebeb0cdfbff67144cf38d843240dd65c30cbd9cab73ae5800a5a6c75aaea3f1e23a6cfee9dbc6cc71c352753\agents\main\sessions\b72812d8-58be-4ee0-bf87-57a1c1cc307d.jsonl` |
| **行号** | 9 |

**错误信息**:
```
agent=main node=auto gateway=default action=photos_latest: node required
```

**原始错误**:
```
agent=main node=auto gateway=default action=photos_latest: node required
```

**原因分析**: Tool 调用时缺少必需参数

---


### Tool Error (write)

#### 记录 #162

| 字段 | 内容 |
|------|------|
| **错误类型** | Tool Error (write) |
| **子类型** | error |
| **错误分类** | 其他错误 |
| **时间戳** | 2026-04-13T02:13:23.391Z |
| **文件位置** | `fa65c292bbe559bed0e01c9bf4ab7206fea633ad01ff275cb3653e15b8eeb8392f5c407ef79ffee6a7cc913e6e645c52665f51d413888ea1d0a0d252182dc6a8\agents\main\sessions\dc9038cf-e21f-41ea-98e4-18512d86f492.jsonl` |
| **行号** | 65 |

**错误信息**:
```
EACCES: permission denied, open '/test_policy_api.py'
```

**原始错误**:
```
EACCES: permission denied, open '/test_policy_api.py'
```

**原因分析**: 需进一步分析具体原因

---

